# 시작용 프로젝트

이 폴더를 Codex에서 열고 weekly-brief Skill이 목록에 보이는지 확인하세요. .agents/skills/weekly-brief/에는 지침과 빈 서식, input/에는 교육용 업무표와 회의 메모가 있습니다.

요청 예:
$weekly-brief
2026-10-30을 기준으로 기획팀의 2026-10-26~2026-10-30 주간업무 보고서 초안을 작성해.
input/tasks.md와 input/meeting-notes.md를 사용해.

이 묶음에는 정답·실행 출력·trace가 없습니다. 실제 사용 기록과 별도 검토자 답안은 강의 참고에서 확인합니다.
